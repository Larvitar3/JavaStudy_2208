package interfaces;

public class ToyRobot {

	String name;

	public void trunOn() {
		System.out.println("장난감 로봇을 켭니다.");
	}

	public void trunOff() {
		System.out.println("장난감 로봇을 끕니다.");
	}

}
