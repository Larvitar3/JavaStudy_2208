package interfaces;

public abstract class HomeAppliances {
	
	int wight;
	int height;
	String color;
	
	public abstract void turnOn();
	
	public abstract void turnOff();

}
