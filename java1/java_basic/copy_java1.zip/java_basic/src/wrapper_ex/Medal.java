package wrapper_ex;

public enum Medal {
	
	
}
