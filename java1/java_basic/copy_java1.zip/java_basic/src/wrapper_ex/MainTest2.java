package wrapper_ex;

public class MainTest2 {
	
	public static void main(String[] args) {
		
		Integer num = new Integer(3); //박싱
//		Number number = 3;
		
		int n = num; // 자동 언박싱
		
	}

}
