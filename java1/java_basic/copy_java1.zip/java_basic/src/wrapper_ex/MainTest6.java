package wrapper_ex;

public class MainTest6 {

	public static void main(String[] args) {

		

	}

}
