package Starcrapt.copy;

public class GateWayMainTestP {

	public static void main(String[] args) {

		GateWay gateWay1 = new GateWay();
		GateWay gateWay2 = new GateWay();
		GateWay gateWay3 = new GateWay();
		GateWay gateWay4 = new GateWay();
		GateWay gateWay5 = new GateWay();
		
		Zealot zealot =  new Zealot("질럿");
		Marine marine = new Marine("마린");
		Zergrling zergrling = new Zergrling("저글링");
		Prove prove = new Prove("프로브");
		Carrier carrier = new Carrier("캐리어");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
