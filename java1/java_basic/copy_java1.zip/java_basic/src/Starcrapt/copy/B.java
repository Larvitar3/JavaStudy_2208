package Starcrapt.copy;

public class B {

	C c;
	public B( ) {
		System.out.println("B 클래스를 메모리에 올려서 객체화");
		c = new C();
		
	}
	
}
