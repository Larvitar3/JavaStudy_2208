package Starcrapt.copy;

public class F {

	G g;
	public F() {
		System.out.println("G객체화");
	}
	
}
