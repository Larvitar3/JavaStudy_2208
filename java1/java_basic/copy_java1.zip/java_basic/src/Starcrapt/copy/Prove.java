package Starcrapt.copy;

public class Prove {

	private String name;
	private int power;
	private int hp;
	
	public Prove(String name) {
		this.name = name;
		this.power = 1;
		this.hp = 20;
	}
	
	public String getName() {
		return name;
	}

	public int getPower() {
		return power;
	}

	public int getHp() {
		return hp;
	}
	
	
	
	
	
	
	
	
}
