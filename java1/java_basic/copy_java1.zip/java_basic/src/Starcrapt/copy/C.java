package Starcrapt.copy;

public class C {
	
	D d;
	public C() {
		System.out.println("c 클래스를 메모리에 올려서 객체화");
		d = new D();
	}
	

}
