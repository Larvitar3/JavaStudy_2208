package Starcrapt.copy;

public class GateWayMainTest2 {

	public static void main(String[] args) {

		int[] numbers = new int[3];
		double[] numbers2 = new double[5];
		
		System.out.println(numbers[2]);
		System.out.println(numbers2[4]);
		
// 	오류 확인 : 배열을 사용할 때 인덱스의 크기와 배열의 길이를 꼭 확인해야한다.	
//		System.out.println(numbers[3]);
		
		// 필요에 따라서 배열 선언과 동시에 초기화를 직접 할 수 있다.
		// ★ String != String[] 완전 다른 데이터타입
		String[] strArr1 = new String[3];
		System.out.println(strArr1[0]);
		
		String[] strArr2 =  new String[] {"안", "녕", "하"};
		System.out.println(strArr2[0]);
		
		int[] intArr = {10, 20, 30}; // 배열 선언과 동시에 초기화
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		GateWay gateWay1 = new GateWay();
//		// 0 1 2 3 4
//		Zealot zealot = null;
//
//		for(int i = 0; i < 5; i++) {
//			System.out.println("i  : " + i);
//			zealot = gateWay1.createZealot();
//			System.out.println(zealot);
//		}
		// 마지막에 생성된 질럿의 주소값만 접근
		
		// 배열이란
		// 연관된 데이터를 통으로 모아서 관리하기 위한 데이터타입
		
		// 모든 프로그램에서 인덱스의 시작은 0부터 시작한다.
		// 인덱스 공식 n - 1
		// 인덱스의 크기는 (길이)n
		
//		인덱스 사용방법 ▼
//		int[] intArr = new int [10];
//		int intArr2[] = new int [5];
//		
//		// 인덱스 연산
//		intArr[0] = 10;
//		intArr[1] = 4;
//		intArr[2] = 10;
//		
//		System.out.println(intArr[0]);
//		System.out.println(intArr[1]);
//		System.out.println(intArr[2]);
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
