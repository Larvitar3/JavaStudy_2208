package Starcrapt.copy;

public class G {

	public G() {
		System.out.println("G객체화");
	}
	
	public static void main(String[] args) {
		A a = new A();
		F f = new F();
		System.out.println(f);
	}
	
}
