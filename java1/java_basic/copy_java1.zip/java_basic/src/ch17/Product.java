package ch17;

public abstract class Product {

	String name;
	public void showInfo() {
		System.out.println("상품명  :  " + name);
	}
	
	
}
