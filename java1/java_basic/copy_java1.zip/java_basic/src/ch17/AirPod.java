package ch17;

public class AirPod extends Product{

	public AirPod() {
		name = "에어팟";
	}
	
}
