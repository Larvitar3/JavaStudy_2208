package ch17;

public class TeddyBear extends Product {

	public TeddyBear() {
		super.name = "작은곰";
	}
	
}
