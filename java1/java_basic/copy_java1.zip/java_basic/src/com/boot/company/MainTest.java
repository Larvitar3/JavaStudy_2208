package com.boot.company;

public class MainTest {

	public static void main(String[] args) {
		
		// 스캐너
		UserInfo userInfo = new UserInfo("1", "123", "홍길동");
		IUserInfoDao infoDao;
//		infoDao.insertUserInfo(userInfo);
		
		
		
	}
	
}
