package ch00;

public class HelloJava2 {

	// main 함수는 코드의 시작점
	public static void main(String[] args) {
		
		// <-- 주석 (저장을 누르면 컴파일 과정을 진행한다. 컴파일 과정에서 무시)
		
		// 화면에 문자열을 출력 해보자.
		
		System.out.println("안녕하세요.^0^");
		System.out.println("");
		System.out.println("반갑습니다. ^0^");
		
		
	} // end of main

} // end of class
