package ch00;

public class HelloJava {
	
	// main (프로그래밍의 시작점)
	public static void main(String[] args) {
		System.out.println("Hello, Java");
		// 명령어의 마지막은 세미콜론으로 마무리 해준다.
	}// <-- 블록 (중괄호)
	// 블록의 범위는 절대적이다.
}
