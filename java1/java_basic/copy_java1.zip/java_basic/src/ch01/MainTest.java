package ch01;

public class MainTest {

	public static void main(String[] args) {
		
		char ch1 = 'A';
		System.out.println(ch1);
		
		// 형변환 (데이터 타입 변환)
		System.out.println((int)ch1); // 인코딩
		
		char ch2 = 'F';
		System.out.println((int)ch2); // 인코딩
		
		char ch3 = 66;
		System.out.println(ch3); // 디코딩
		
		char ch4 = '안';
		char ch5 = '녕';
		char ch6 = '하';
		char ch7 = '세';
		char ch8 = '요';
		System.out.print((int)ch4);
		System.out.print((int)ch5);
		System.out.print((int)ch6);
		System.out.print((int)ch7);
		System.out.println((int)ch8);
		
		int a = 65;
		System.out.println((char)a);
		

	}

}





















