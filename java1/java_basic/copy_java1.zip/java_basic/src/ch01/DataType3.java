package ch01;

public class DataType3 {
	
	public static void main(String[] args) {
		
		// 변수 : 기본데이터 타입, 참조자료형
		
		//  기본데이터 타입
		// 실수형 :  float, double
		
		float a = 0.5F; // 접미사 사용
		float b = (float)0.5; // 형 변환으로도 변경 가능하다
		
		double c = 0.12345; // 실수형의 기본 연산 단위 (접미사 사용 X)
		double d = 1.12345;
		
		// 소수점을 많이 표시할 수 있기 때문에 정확성을 더 보장한다.
		
		
		
	} // end of main
} //  end of class
