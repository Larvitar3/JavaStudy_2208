package ch11;

public class EmployeeMaunTest {

	public static void main(String[] args) {
		
		Employee employee1 = new Employee();
		Employee employee2 = new Employee();
		Employee employee3 = new Employee();
		
		employee1.setEmpName("김춘식");
//		employee.setEmpId(1);
		
		System.out.println(employee1.getEmpId());
		System.out.println(employee1.getEmpName());
		
		employee2.setEmpName("김춘삼");
//		employee.setEmpId(2);
		
		System.out.println(employee2.getEmpId());
		System.out.println(employee2.getEmpName());
		
		
		employee3.setEmpName("김춘사");
//		employee.setEmpId(2);
		
		System.out.println(employee3.getEmpId());
		System.out.println(employee3.getEmpName());
		
		System.out.println("====================");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
