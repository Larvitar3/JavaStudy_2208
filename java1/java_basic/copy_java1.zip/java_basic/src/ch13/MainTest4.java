package ch13;

public class MainTest4 {

	public static void main(String[] args) {
		
		Car car = new Car("벤츠", 1000);
		
//		car.name = "벤츠";
//		car.price = 7200;
		
//		car.engin.name = "육기통";
//		car.engin.price = 1000;
		
		System.out.println(car.name);
		
		
	}

}
