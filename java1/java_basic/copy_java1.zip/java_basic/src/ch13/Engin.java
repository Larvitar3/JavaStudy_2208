package ch13;

public class Engin {

	// 속성
	// 엔진 이름
	// 엔진 가격
	String name;
	int price;
	
	
}
