package ch13;

public class MainTest5 {

	public static void main(String[] args) {
		
		Customer customer1 = new Customer();
		// customer1. : 보너스 포인트 보임. 보너스 비율 보임.
		
		Customer customer2 = new VIPCustomer();
		// customer2. : 보너스 포인트 보임. 보너스 비율 보임.
		
		
		
		VIPCustomer vipCustomer1 = new VIPCustomer();
		// vipCustomer1. 보너스 포인트 보임. 보너스 비율 보임,
		
		
		
		
		
		
	}
	
}
