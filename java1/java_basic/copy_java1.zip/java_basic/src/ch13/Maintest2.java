package ch13;

public class Maintest2 {

	public static void main(String[] args) {
		
		Cal2  cal2 = new Cal2();
		
		
		int result2 = cal2.multiply(2, 2);
		System.out.println(result2);
		

	}

}
