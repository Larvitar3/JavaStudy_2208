package generic_ex.ch03;

public class Water {
	
	@Override
	public String toString() {
		return "재료는 물입니다.";
	}

}
