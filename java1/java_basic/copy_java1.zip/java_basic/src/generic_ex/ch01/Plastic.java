package generic_ex.ch01;

public class Plastic {
	
	@Override
	public String toString() {
		return "재료는 플라스틱 입니다.";
	}


}
