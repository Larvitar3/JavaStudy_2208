package generic_ex.ch01;

public class ThreedPrinter3 {

	private Object material;

	public Object getMaterial() {
		return material;
	}

	public void setMaterial(Object material) {
		this.material = material;
	}
	
}
