package generic_ex.ch01;

public class ThreedPrinter1 {
	
	// 재료
	private Powder metertial;

	public Powder getMetertial() {
		return metertial;
	}

	public void setMetertial(Powder metertial) {
		this.metertial = metertial;
	}
	

	

}
