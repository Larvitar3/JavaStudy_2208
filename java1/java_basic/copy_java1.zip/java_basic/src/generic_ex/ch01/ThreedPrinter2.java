package generic_ex.ch01;

public class ThreedPrinter2 {
	
	// 재료
	private Plastic material;

	public Plastic getMaterial() {
		return material;
	}

	public void setMaterial(Plastic material) {
		this.material = material;
	}
	
	
	

	

}
