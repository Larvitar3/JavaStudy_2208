package ch04;

public class ForMainTest1 {

	public static void main(String[] args) {
		
		// 화면에 구구단 2단을 출력해 보세요.
		
		int num1 = 2;
		int num2 = 1;
		
//		System.out.println(num1 + "단");
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		
//		System.out.println();
//		
//		num1 = 3;
//		num2 = 1;
//		System.out.println(num1 + "단");
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		
//System.out.println();
//		
//		num1 = 4;
//		num2 = 1;
//		System.out.println(num1 + "단");
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//
//System.out.println();
//		
//		num1 = 5;
//		num2 = 1;
//		System.out.println(num1 + "단");
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 +  " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		System.out.println( num1 + " X "+ num2+  " = " + (num1 * num2));
//		num2++;
//		
//		System.out.println("===============================");
//		System.out.println(num1 + "단");
		
		// 문법모양
		// for (조건식) {수행문}
		System.out.println("===============================");
	    System.out.println(num1 + "단");
	    
	    
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		num1++;
		System.out.println("===============================");
	    System.out.println(num1 + "단");
		for(int i = 1; i < 10;  i++) {
			System.out.println( num1 + " X "+ i +  " = " + (num1 * i));
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
