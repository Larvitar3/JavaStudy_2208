package ch05;

public class Order {

	int orderId;
	String buyerld;
	String sellerld;
	int productld;
	String orderDate;
	
	
}
