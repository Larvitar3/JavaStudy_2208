package ch05;

public class MainTest2 {
	// 메인 함수 ( member 변수)
	int num1; // 멤버변수 (값을 할당하지 않으면 멤버 변수는 기본값으로 알아서 초기화)
	

	public static void main(String[] args) {
		
		// 메인 함수 영역
		// 지역 변수
		int temp1;
		System.out.println();
	}
	public static int addNumber(int n1, int n2) {
		int result; // 지역변수 (반환하려면 반드시 값을 지정(초기화)해주야한다)
		result = 10;
		return result;
	}

}
