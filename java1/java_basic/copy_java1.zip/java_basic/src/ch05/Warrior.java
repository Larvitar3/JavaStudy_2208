package ch05;

public class Warrior {
	
	// 상태
	String name;
	int height;
	int power;
	String color;
	
	// 행위

}
