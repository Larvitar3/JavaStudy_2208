package ch05;

public class Warrior2 {

	String name;
	int height;
	int power;
	String color;
	
}
