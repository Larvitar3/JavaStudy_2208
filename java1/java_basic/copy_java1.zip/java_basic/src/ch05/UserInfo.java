package ch05;

public class UserInfo {
	
	String userId; // 식별자
	String userPassword;
	String userName;
	String userAddres;
	int phoneNubber; // 긴 경우 String 사용

	/*
	 * 
	 *  클래스는 대문자로 시작한다.
	 * 
	 * */
	
}

class School{ // 하나의 자바 파일에 클래스는 여러개 생성할 수 있으나 퍼블릭은 한번만 사용 가능
	String name;
}
