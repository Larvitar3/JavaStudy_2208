package ch05;

public class Student2 {

	// 객체의 상태(속성)는 클래스의 멤버 변수로 선언한다
	int studentNuber;
	String studentName;
	int majorCode;
	int grade;
	
	
}
