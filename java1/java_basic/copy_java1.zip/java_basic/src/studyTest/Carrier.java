package studyTest;

public class Carrier {

	private String name;
	private int power;
	private int hp;
	
	public Carrier(String name) {
		this.name = name;
		this.power = 10;
		this.hp = 40;
	}
	
	public String getName() {
		return name;
	}

	public int getPower() {
		return power;
	}

	public int getHp() {
		return hp;
	}
	
	
	
	
	
	
	
	
	
}
