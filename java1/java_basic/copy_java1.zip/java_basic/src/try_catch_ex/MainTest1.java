package try_catch_ex;

public class MainTest1 {

	class Dog {

	}

	public static void main(String[] args) {
//		Dog dog = null;
//		System.out.println(dog);

//		Exception exception;

		
		try {
			// 예외가 발생할 수 있는 문자
		} catch (Exception e) {
			// 에외 발생 시 실행할 문자
		}

	}

}
