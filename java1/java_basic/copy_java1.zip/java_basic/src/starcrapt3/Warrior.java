package starcrapt3;

public class Warrior extends Hero {

	public Warrior(String name, int hp) {
		super(name, hp);
	}

	public void comboAttack() {
		System.out.println("전사가 연속공격을 합니다.");
	}
	
	
}
