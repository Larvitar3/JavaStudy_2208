package starcrapt3;

public interface Terran extends UnitAttacker{

	public abstract void attack(Unit unit);
	
}
