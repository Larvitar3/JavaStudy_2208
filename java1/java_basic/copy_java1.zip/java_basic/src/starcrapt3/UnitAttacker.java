package starcrapt3;

public interface UnitAttacker {

	public abstract void attack(Unit unit);
	
}
