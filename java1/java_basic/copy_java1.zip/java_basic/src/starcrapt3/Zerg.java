package starcrapt3;

public interface Zerg extends UnitAttacker{

	
}
