package starcrapt3;

public interface Protoss extends UnitAttacker{

//	public abstract void attack(Zealot zealot);
//	public abstract void attack(Marine marine);
//	public abstract void attack(Zergrling zergrling);
	// 상속관계의 클래스로 코드 줄이기 ▼
	
//	public abstract void skill(Unit unit);
//	public abstract void skill();
//	
	
}
