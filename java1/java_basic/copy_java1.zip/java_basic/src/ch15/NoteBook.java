package ch15;

public abstract class NoteBook extends Computer {

	@Override
	public void typing() {
		System.out.println("노트북에서 타이핑을 합니다.");
	}
	
}
