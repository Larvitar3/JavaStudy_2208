package ch15;

public class DeskTop extends Computer{

	@Override
	public void display() {
		System.out.println("화면이 출력됩니다.");
	}

	@Override
	public void typing() {
		System.out.println("타이핑을 합니다.");
	}

	
	
}
