package ch15;

public class Person extends Human {

	@Override
	public void hunt() {
		System.out.println("사람이 총을 들고 독수리르 사냥합니다.");
		
	}

	
	
}
