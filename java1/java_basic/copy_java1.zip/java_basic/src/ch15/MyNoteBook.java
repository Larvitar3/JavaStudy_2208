package ch15;

public class MyNoteBook extends NoteBook{

	@Override
	public void display() {
		System.out.println("나의 노트북 화면이 출력됩니다");
	}

}
