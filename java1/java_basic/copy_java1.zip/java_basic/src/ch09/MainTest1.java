package ch09;

public class MainTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
