package threadex;

import java.util.Iterator;

public class MainTest1 {

	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			System.out.println("-");
		}
		
		
	}

}
