package interfaces2;

public abstract class HomeAppliances {
	
	int wight;
	int height;
	String color;
	

}
