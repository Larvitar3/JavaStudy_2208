package interfaces2;

public interface SoundEffect {

	public abstract void soundOn();
	
}
