package callback_ex.calenderEx;

public interface OnWriteArticle {
	// MyArticle클래스와 HackerNews 클래스에 약속으로 사용 할 예정.
	void printNews(String article);

}
