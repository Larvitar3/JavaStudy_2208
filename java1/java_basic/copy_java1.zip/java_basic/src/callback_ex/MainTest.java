package callback_ex;

public class MainTest {

	public static void main(String[] args) {

		new MainActivity();
//		new SubActivity();
		
	}

}
