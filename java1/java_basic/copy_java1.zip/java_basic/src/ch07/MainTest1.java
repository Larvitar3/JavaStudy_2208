package ch07;

public class MainTest1 {

	public static void main(String[] args) {
		
//		Student student1 = new Student(10, "김춘식", 3);
//		student1.number = 1;
//		student1.name = "김춘식";
//		student1.grade = 1;
		
		// 기본 생성자 
		// 컴파일러가 기본적으로 만들어주는 생성자
		Student student1 = new Student();
		// 사용자 정의 생성자
		// 
	

		
		// 생성자 (constructor)
		

	}

}
