package ch07;

public class MainTest3 {

	public static void main(String[] args) {
		
		Person person1 = new Person(180, 78, "남성", "Tomas", 37);

		System.out.println(person1.ShowInfo());
		
//		Person person2 = new Person();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	} // end of main

}
