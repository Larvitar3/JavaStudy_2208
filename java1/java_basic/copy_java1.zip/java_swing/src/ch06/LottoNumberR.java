package ch06;

import java.util.Random;

public class LottoNumberR {
	
	
}
