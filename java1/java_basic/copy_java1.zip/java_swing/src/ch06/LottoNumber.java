package ch06;

import java.util.Random;

import javax.swing.JPanel;

public class LottoNumber extends JPanel {
	public static void main(String[] args) {
		

	}
}
