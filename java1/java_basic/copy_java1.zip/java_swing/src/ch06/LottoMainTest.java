package ch06;

import java.util.Random;

public class LottoMainTest {

	public static void main(String[] args) {

		new Lotto();
		
		
	}

}
