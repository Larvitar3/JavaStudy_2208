package ch03;

public class MainTest2 {

	public static void main(String[] args) {

		MyBufferedImage bufferedImage = new MyBufferedImage();
		
	}

}
