package Games;

public class MiniGame {
	
	public static void main(String[] args) {
		new MainFrame();
	}

}
