package ch05;

public class MianTest2 {

	public static void main(String[] args) {
		new MyFrame6();

	}

}
