package ch05;

public class MainTest3 {

	public static void main(String[] args) {

		new MyFrame7();
		
	}

}
