package ch05;

public abstract class MoveableAdpter implements Moveable{

	@Override
	public void left() {}

	@Override
	public void right() {}

	@Override
	public void up() {}

	@Override
	public void down() {}

	
	
}
