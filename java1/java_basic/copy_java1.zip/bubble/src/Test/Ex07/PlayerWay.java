package Test.Ex07;

public enum PlayerWay {
	LEFT, RIGHT
}
