package Test.test;

public enum PlayerWay {
	LEFT, RIGHT
}
