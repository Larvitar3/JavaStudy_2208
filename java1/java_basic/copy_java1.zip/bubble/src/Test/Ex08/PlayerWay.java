package Test.Ex08;

public enum PlayerWay {
	LEFT, RIGHT
}
