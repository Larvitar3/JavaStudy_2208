package Test.Ex12;

public enum PlayerWay {
	LEFT, RIGHT
}
