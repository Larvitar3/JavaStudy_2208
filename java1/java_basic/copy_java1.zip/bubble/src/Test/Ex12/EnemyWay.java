package Test.Ex12;

public enum EnemyWay {
	LEFT, RIGHT
}
