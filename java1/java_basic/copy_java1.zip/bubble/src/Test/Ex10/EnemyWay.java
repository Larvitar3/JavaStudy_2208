package Test.Ex10;

public enum EnemyWay {
	LEFT, RIGHT
}
