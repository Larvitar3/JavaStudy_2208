package Test.Ex10;

public enum PlayerWay {
	LEFT, RIGHT
}
