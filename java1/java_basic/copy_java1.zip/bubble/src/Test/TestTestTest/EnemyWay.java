package Test.TestTestTest;

public enum EnemyWay {
	LEFT, RIGHT
}
