package Test.TestTestTest;

public enum PlayerWay {
	LEFT, RIGHT
}
