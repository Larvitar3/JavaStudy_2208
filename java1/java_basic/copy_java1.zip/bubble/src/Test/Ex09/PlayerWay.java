package Test.Ex09;

public enum PlayerWay {
	LEFT, RIGHT
}
