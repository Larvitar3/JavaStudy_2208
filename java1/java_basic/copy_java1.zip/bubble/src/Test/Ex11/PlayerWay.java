package Test.Ex11;

public enum PlayerWay {
	LEFT, RIGHT
}
