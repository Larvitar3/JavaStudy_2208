package game.stat;

public enum EnemyWay {
	LEFT, RIGHT
}
