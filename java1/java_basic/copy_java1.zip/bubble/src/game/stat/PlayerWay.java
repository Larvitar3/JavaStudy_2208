package game.stat;

public enum PlayerWay {
	LEFT, RIGHT
}
